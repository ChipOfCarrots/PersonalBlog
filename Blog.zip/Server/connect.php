<?php 
header("Content-Type: application/json");
 
$db_host = "localhost"; 
$db_user = "root"; 
$db_pass = ""; 
$db_name = "intdesblog"; 
$db_table = "notice";
$db_query_all = "SELECT * FROM $db_table";


$conn = mysql_connect($db_host,$db_user,$db_pass); 
if (!(mysql_select_db($db_name,$conn))) { 
        echo "Could not connect to the database"; 
 } else {
	$result =  mysql_query("$db_query_all");
	$i = 0;
 while ($obj = mysql_fetch_object($result)) {
	 $notice[$i] = clone $obj;
	 $i++; 
    }	
echo json_encode($notice);	
}
mysql_close($conn);
?>
