// JavaScript Document	
"use strict";
function get_MostRecent(){
$.getJSON('http://localhost/blog/Server/connect.php', function(responseText){
var myjson = responseText;
var maxlength = myjson.length -1;
var forto = 4; if (maxlength < 5){forto = maxlength;}
var i; for (i=0; i<=forto; i++) { 
//insert sintax for home;
}
});}